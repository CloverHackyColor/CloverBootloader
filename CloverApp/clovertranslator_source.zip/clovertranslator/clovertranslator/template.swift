//
//  template.swift
//  clovertranslator
//
//  Created by vector sigma on 03/04/2020.
//  Copyright © 2020 vectorsigma. All rights reserved.
//

import Foundation

let kCommentLine = "kCommentLine**#"
let kInlineCommentPrefix = "kInlineCommentPrefix**#"
let kEmptyLine = "kEmptyLine**#"

func getHeader(for language: String) -> String {
  let header = """
/*
Clover.app
language code: \(language == "base" ? "en" : language)

Copyright © 2019-\(Calendar.current.component(.year, from: Date())) CloverHackyColor. All rights reserved.
*/\n\n
"""
  
  return header
}

//
//  main.swift
//  clovertranslator
//
//  Created by vector sigma on 03/04/2020.
//  Copyright © 2020 vectorsigma. All rights reserved.
//

import Foundation

/*
 This program update all the strings files inside CloverApp/Lang.bundle/Contents/Resources
 by filling all them with newer keys.
 The base language and all the needed keys are taken from the template.plist file
 which contains the "Index" (to sort the keys) and all the key-value pairs in English
 under "Translations".
 
 NOTE:
 When updating, the en.strings is always generated from scratch while all other
 strings are only updated with new keys (if any).
 Order and comments are anyway conformed to what's on template.plist so that all
 the strings files will have the same layout.
 This will help when translators will give us new or updated (but messed) files.
 
 clovertranslator and Lang.bundle must be in the same directory (at the same level)
 for this to work.
 
 WARNING:
 Any modifications to template.plist causes the lost of translations (if you remove some thing)
 or the additions of new keys (if you add any) to all the strings files.
 
 This is meant to replace the gettext command line which take a life to compile and is not
 really portable.
 */

let fm = FileManager.default
let myDir = CommandLine.arguments[0].deletingLastPath
let basePlisPath = myDir.addPath("template.plist")
if !fm.fileExists(atPath: basePlisPath) {
  print("Error: \(basePlisPath), no such file.")
  exit(EXIT_FAILURE)
}

let aDict = NSDictionary(contentsOfFile: basePlisPath) as? [String: Any]

if aDict == nil {
  print("Error: cannot load template.plist")
  exit(EXIT_FAILURE)
}

let baseDict = aDict!

if (baseDict["Index"] as? [String]) == nil {
  print("Error: template.plist does'ncontain the required Index array")
  exit(EXIT_FAILURE)
}

if (baseDict["Translations"] as? [String : Any]) == nil {
  print("Error: template.plist does'ncontain the required Translations dictionary")
  exit(EXIT_FAILURE)
}

let baseIndex : [String] = baseDict["Index"] as! [String]
let baseTranslations : [String: Any] = baseDict["Translations"] as! [String : Any]

func updatedStringsFile(at path: String) -> String {
  if !fm.fileExists(atPath: path) {
    print("Error: \(path), no such file.")
    exit(EXIT_FAILURE)
  }
  
  let fileName = path.lastPath
  
  if fileName.fileExtension != "strings" {
    print("Error: \(fileName) is not a strings file.")
    exit(EXIT_FAILURE)
  }
  print("Updating: \(fileName)")
  let langCode : String = fileName.deletingFileExtension
  let actual = NSDictionary(contentsOfFile: path) as? [String: Any]
  
  var translationFile : String = getHeader(for: langCode)
  for i in 0..<baseIndex.count {
    let str = baseIndex[i]
    if str.hasPrefix(kCommentLine) {
      translationFile += "// " + str.components(separatedBy: kCommentLine)[1] + "\n"
    } else if str == kEmptyLine {
      translationFile += "\n"
    } else {
      if !str.hasPrefix(kInlineCommentPrefix) {
        let actualTranslation : String? = actual?[str] as? String
        let translation : String = (actualTranslation ?? (baseTranslations[str] as! String)).trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        translationFile += "\"\(str)\" = \"\(translation)\";"
        if i < (baseIndex.count - 1) {
          let next = baseIndex[i + 1]
          if next.hasPrefix(kInlineCommentPrefix) {
            translationFile += " // " + next.components(separatedBy: kInlineCommentPrefix)[1] + "\n"
          } else {
            translationFile += "\n"
          }
        } else {
          translationFile += "\n"
        }
      }
    }
  }
  
  // test the file
  var test : [String : Any]? = nil
  do {
    if fm.fileExists(atPath: "/tmp/new.strings") {
      try fm.removeItem(atPath: "/tmp/new.strings")
    }
    try translationFile.write(to: URL(fileURLWithPath: "/tmp/new.strings"),
                              atomically: true,
                              encoding: .utf8)
    test = NSDictionary(contentsOf: URL(fileURLWithPath: "/tmp/new.strings")) as? [String : Any]
    try fm.removeItem(atPath: "/tmp/new.strings")
  } catch {
    print(error.localizedDescription)
    exit(EXIT_FAILURE)
  }
  if test == nil {
    print("Error: generated \(fileName) is invalid.")
    exit(EXIT_FAILURE)
  }
  return translationFile
}


let stringsPath = myDir.addPath("Lang.bundle/Contents/Resources")

if !fm.fileExists(atPath: stringsPath) {
  print("Error: \(stringsPath), no such directory.")
  exit(EXIT_FAILURE)
}

// re-new en.strings
try? fm.removeItem(atPath: stringsPath.addPath("en.strings"))

try? "".write(to: URL(fileURLWithPath:stringsPath.addPath("en.strings")),
              atomically: false,
              encoding: .utf8)

// collect existings strings file
do {
  let files = try fm.contentsOfDirectory(atPath: stringsPath)
  
  for file in files {
    let fullPath = stringsPath.addPath(file)
    if file.fileExtension == "strings" {
      let new = updatedStringsFile(at: fullPath)
      if new.count > 0 {
        try fm.removeItem(atPath: fullPath)
        try new.write(to: URL(fileURLWithPath: fullPath), atomically: true, encoding: .utf8)
      }
    }
  }
} catch {
  print(error.localizedDescription)
}


//
//  Extensions.swift
//  clovertranslator
//
//  Created by vector sigma on 03/04/2020.
//  Copyright © 2020 vectorsigma. All rights reserved.
//

import Foundation

extension String {
  public func noSpaces() -> String {
    return self.trimmingCharacters(in: CharacterSet.whitespaces)
  }
  
  var lastPath: String {
    return (self as NSString).lastPathComponent
  }
  
  var fileExtension: String {
    return (self as NSString).pathExtension
  }
  
  var deletingLastPath: String {
    return (self as NSString).deletingLastPathComponent
  }
  
  var deletingFileExtension: String {
    return (self as NSString).deletingPathExtension
  }
  
  var componentsPath: [String] {
    return (self as NSString).pathComponents
  }
  
  func addPath(_ path: String) -> String {
    let nsSt = self as NSString
    return nsSt.appendingPathComponent(path)
  }
  
  func appendingFileExtension(ext: String) -> String? {
    let nsSt = self as NSString
    return nsSt.appendingPathExtension(ext)
  }
}
